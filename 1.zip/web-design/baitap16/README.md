## *Bài Tập 16*: [Click to go to page](https://exercise.nguyenthanhdat.space/web-design/baitap16/index.html)


